tokenPriority = {
  sp: "SP",
  se: "SE",
  sg: "SG",
};

module.exports = tokenPriority;
